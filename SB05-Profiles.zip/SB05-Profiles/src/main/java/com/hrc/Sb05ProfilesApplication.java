package com.hrc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb05ProfilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sb05ProfilesApplication.class, args);
	}

}
