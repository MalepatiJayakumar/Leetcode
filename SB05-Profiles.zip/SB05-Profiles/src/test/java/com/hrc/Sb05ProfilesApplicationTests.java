package com.hrc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb05ProfilesApplicationTests {

	@Test
	void contextLoads() {
	}

}
